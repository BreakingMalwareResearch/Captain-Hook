from HooksScan import *
import sys
import os
System.request_debug_privileges()
proc_to_scan = None
scan_by_pid = False

if len(sys.argv) > 1:
	try:
		proc_to_scan = int(sys.argv[1])
		scan_by_pid = True
	except:
		proc_to_scan = sys.argv[1].lower()

summary = []
print "Starting to scan:"
print "Press Ctrl-C to Stop"

for process in system:
	if process.get_filename():
		if proc_to_scan is None or (scan_by_pid and process.get_pid() == proc_to_scan) or (not scan_by_pid and proc_to_scan in process.get_filename().lower()):
			try:
				print 
				print "-----------------------------------------------------------------"
				print "Scanning %d:\t%s" % ( process.get_pid(), process.get_filename() )        
				# try:
				hooks = []
				scan_for_bad_hooks(process, hooks)
				if hooks:
					suspicious_modules = set([])
					for hook in hooks:
						prev = "Unknown"
						for callsite in hook.callsites:
							if callsite.unsafe and not callsite.writable:
								module = callsite.path if callsite.module != "Runtime Code" else prev
								if not module in suspicious_modules:
									print
									print "Vulnerable Detours Engine detected. Suspicious Product Dll: %s" % (module)
									summary.append((process.get_pid(), process.get_filename().split("\\")[-1], module))
									suspicious_modules.add(module)
							prev=callsite.path
			except KeyboardInterrupt as ex:
				print 
				print "Scan Stopped."
				break
			except Exception as ex:
				print
				print "Can't Scan %s" % (process.get_filename())	

print
if (summary):
	print "Vulnerable applications found:"

	headers =  ["PID", "Process", "Suspicious DLL"]
	print
	print tabulate.tabulate(summary, headers, tablefmt="grid")
	os.system('pause')
else:
	print "No vulnerable applications found"