from winappdbg import System
from winappdbg import win32, Process, HexDump
import pefile
import struct
import sys
import tabulate
import distorm3
# Create a system snaphot.
system = System()
UNSAFE_ENGINES = set(["Detours-Unsafe"])
class CallsiteData:
	def __init__(self, module, source, target, writable=False, signed=False, engine="", path=""):
		self.module = module
		self.source = source
		self.target = target
		self.writable = writable
		self.unsafe = self.writable or (engine in UNSAFE_ENGINES)
		self.signed = signed
		self.engine = engine
		self.path = path

class HookData:
	def __init__(self, module, export_name, callsites=[]):
		self.module = module
		self.export_name = export_name
		self.callsites = callsites

	def to_tuple(self):
		callsite = self.callsites[0]
		return ("%s.%s" % (self.module.rsplit(".", 1)[0],self.export_name), callsite.module, "0x%x" % callsite.source, "0x%x" % callsite.target if callsite.target else "Not Hook", "V" if callsite.writable else "X", "V" if callsite.signed else "X", "V" if callsite.unsafe else "X", callsite.engine)

	def to_rows(self):
		rows = [self.to_tuple()]
		if len(self.callsites) > 1:
			for callsite in self.callsites[1:]:
				rows.append( ("", callsite.module, "0x%x" % callsite.source, "0x%x" % callsite.target if callsite.target else "Unknown", "V" if callsite.writable else "X", "V" if callsite.signed else "X", "V" if callsite.unsafe else "X", callsite.engine) )
		return rows

def iterate_possible_hook_targets(process, hook_address, code, first_inst_only, is64):
	possible_push_target = 0
	reg_value = None
	reg_type = None
	call_target = 0	

	for op in distorm3.DecomposeGenerator(hook_address, code, distorm3.Decode32Bits if not is64 else distorm3.Decode64Bits):
		if not op.valid:
			continue
		found_special = False
		short = False
		# check if its a push-ret combo
		if op.mnemonic == "PUSH" and op.operands[0].size == 32:
			possible_push_target = op.operands[0].value
			found_special = True
		elif op.flowControl == 'FC_UNC_BRANCH' or op.flowControl == 'FC_CALL':
			if (op.operands[0].type == 'Immediate'):
				# if its a short jump we have a special treatment
				if (op.operands[0].size == 8):
					short = True
				call_target = op.operands[0].value
			elif (op.operands[0].type == 'Register'):
				# check if there was a mov to register before the jmp
				if reg_type and op.operands[0].name == reg_type:
					call_target = reg_value
			elif (op.operands[0].type == 'AbsoluteMemoryAddress'):
				try:
					# dereference the memory address				
					call_target = process.read_dword(op.operands[0].disp)
				except:
					pass
			elif (op.operands[0].type == 'AbsoluteMemory'):
				if (is64 and op.operands[0].size == 64 and op.operands[0].base is None):
					# its a RIP+X instruction
					call_target = process.read_qword(op.address + op.size + op.operands[0].disp)
		elif op.mnemonic == "MOV" and op.operands[0].type == 'Register' and op.operands[1].type == "Immediate":
			reg_type = op.operands[0].name
			reg_value = op.operands[1].value
			found_special = True
		elif op.mnemonic == "RET":
			# check if there was a jmp before the ret
			if possible_push_target:
				call_target = possible_push_target
			possible_push_target = 0

		if (not found_special):
			possible_push_target = 0
			reg_type = None
			reg_value = None

		if (call_target):
			yield (op.address, call_target, short)
		if first_inst_only:
			break

def detect_engine(process, mbi, is64):
	# Check if its detours. (dtrR magic)
	if (process.read_dword(mbi.AllocationBase) == 0x52727464 ):
		if mbi.AllocationBase == 0x6FFF0000 or mbi.AllocationBase == 0x4FFF0000:
			return "Detours-Unsafe"
		else:
			return "Detours"
	elif mbi.AllocationBase == 0x6FFF0000 or mbi.AllocationBase == 0x4FFF0000:
		# Detours used both of the constants
		return "Detours-Unsafe"
	elif ( (is64 and process.read_qword(mbi.AllocationBase+0x13) == mbi.AllocationBase) or (not is64 and process.read_dword(mbi.AllocationBase+0x12) == mbi.AllocationBase)):
		return "Deviare2"

	return "Unknown"

def get_hook_call_chain(process, modules_map, hook_address, is64=False):	
	first = True
	call_chain = []
	hooks_sites = set([])
	allocation_base_set = set([])
	base_modules = set(["ntdll.dll", "kernel32.dll", "kernelbase.dll", "user32.dll"])
	hooked_module = modules_map.get(process.mquery(hook_address).AllocationBase)
	hooked_module_signed = False
	hooked_module_path = None
	if hooked_module:
		hooked_module_name = hooked_module.filename
		hooked_module_path = hooked_module.path
		hooked_module_signed = hooked_module.signed
	else:
		hooked_module_name = "Runtime Code"
	start_address = hook_address
	while True:
		size = 0x200	
		code = None	
		while not code and size > 10:
			try:
				code = process.read(hook_address, size)				
			except:
				pass
			size = size/2
		if not code:
			return call_chain


		next_hook = None
		hooking_module_name = None
		hooking_module_sigend = False
		for address, call_target, is_short in iterate_possible_hook_targets(process, hook_address, code, first, is64):
			# it looks like we found a call target.
			# check if its real.
			mbi = None
			engine = ""

			# we follow short jmp only if its the first site.
			if is_short and not first:
				continue
			try:
				mbi = process.mquery(call_target)
			except:
				pass
			if mbi:
				if hooked_module_name == "Runtime Code":
					engine = detect_engine(process, process.mquery(address), is64)
				# check if the memory is commited and executable.
				if (not (mbi.AllocationBase in allocation_base_set) and mbi.is_executable()):

					# check if we got back to the start.
					if not first and 0 <= (call_target - start_address) <= 0x10:
						mbi = process.mquery(address)
						call_chain.append(CallsiteData(hooked_module_name, address, call_target, mbi.is_executable_and_writeable(), hooked_module_signed, engine, hooked_module_path))
						return call_chain
					hooking_module = modules_map.get(mbi.AllocationBase, None)
					if hooking_module:
						hooking_module_name = hooking_module.filename
						hooking_module_path = hooking_module.path						
						hooking_module_sigend = hooking_module.signed
						# if its a short jmp its ok to stay in a base module.
						if not is_short and hooking_module_name.lower() in base_modules:
							hooking_module_name = None
						else:
							# Add the current allocation base to the chain.
							allocation_base_set.add(mbi.AllocationBase)
					else:
						hooking_module_name = "Runtime Code"

					# This seems like a hook target
					if hooking_module_name:					
						mbi = process.mquery(address)
						call_chain.append(CallsiteData(hooked_module_name, address, call_target, mbi.is_executable_and_writeable(), hooked_module_signed, engine, hooked_module_path))
						next_hook = call_target
						break

		first = False
		if not next_hook:
			# We didnt find where to proceed. Add the last hook address to the call chain
			mbi = process.mquery(hook_address)
			call_chain.append(CallsiteData(hooked_module_name, hook_address, None, mbi.is_executable_and_writeable(), hooked_module_signed, engine, hooked_module_path))
			return call_chain

		# We are probably in a loop
		if next_hook in hooks_sites:
			call_chain[-1].target = None
			return call_chain
		hooks_sites.add(next_hook)
		hook_address = next_hook
		hooked_module_name = hooking_module_name
		hooked_module_path = hooking_module_path
		hooked_module_signed = hooking_module_sigend

from winappdbg.util import PathOperations
class ModuleMap(dict):
	PE_FILES_EXPORTS_CACHE = {}

	class MappedModule:
		def __init__(self, path, base_address):
			self.path = path
			self.base_address = base_address
			exports = []
			is_signed = False
			if not self.path in ModuleMap.PE_FILES_EXPORTS_CACHE:
				pe = pefile.PE(path, fast_load=True)
				pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_EXPORT']])
				
				if pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_SECURITY'] < len(pe.OPTIONAL_HEADER.DATA_DIRECTORY) and pe.OPTIONAL_HEADER.DATA_DIRECTORY[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_SECURITY']].VirtualAddress != 0:
					is_signed = True

				if hasattr(pe, "DIRECTORY_ENTRY_EXPORT"):
					for export in pe.DIRECTORY_ENTRY_EXPORT.symbols:

						if not export.forwarder is None:
							continue
						
						# get the rva of the export
						export_rva = export.address

						section = pe.get_section_by_rva(export_rva)

						if not (section) or not section.__dict__.get('IMAGE_SCN_MEM_EXECUTE', False):
							continue

						# get the original byte
						function_original_byte = ord(pe.get_data(export_rva, 1)[0])
						exports.append((export.name, export_rva, function_original_byte))

					ModuleMap.PE_FILES_EXPORTS_CACHE[self.path] = (exports, is_signed)
			else:
				exports, is_signed = ModuleMap.PE_FILES_EXPORTS_CACHE[self.path]
			self.exports = exports
			self.signed = is_signed

		def get_base(self):
			return self.base_address

		def __str__(self):
			return self.path

		
		@property
		def filename(self):
			return self.path.rsplit("\\", 1)[-1]

	def __init__(self, process):
		dict.__init__(self)

		hProcess = process.get_handle( win32.PROCESS_VM_READ | win32.PROCESS_QUERY_INFORMATION )

		memoryMap = process.get_memory_map()        
		for mbi in memoryMap:
			allocationBase = mbi.AllocationBase
			if mbi.Type not in (win32.MEM_IMAGE,) or allocationBase in self:
				continue
				
			fileName    = ""
			try:
				fileName = win32.GetMappedFileName(hProcess, allocationBase)
				fileName = PathOperations.native_to_win32_pathname(fileName)
			except WindowsError, e:
				continue

			self[allocationBase] = ModuleMap.MappedModule(fileName, allocationBase)
			
			sys.stdout.write( '.' )
			sys.stdout.flush()

	def iter_modules(self):
		return self.values()



def scan_for_bad_hooks( process, hooks ):
	modules = ModuleMap(process)
	for module in modules.iter_modules():		
		for export_name, export_rva, function_original_byte in module.exports:
			# get the in-memory byte
			try:
				inmemory_byte = process.read_char(module.get_base() + export_rva)
				func_addr = module.get_base() + export_rva
				# check for a hook.
				if (inmemory_byte != function_original_byte):
					

					if inmemory_byte != 0xe8:
						chain = get_hook_call_chain(process, modules, func_addr, process.get_bits() == 64)

						# we have a trampoline chain.
						if chain:
							hooks.append(HookData(hooked_module, export_name, chain))
						else:
							mbi = process.mquery(func_addr)
							# we mark it as writable because it should be rare that we cant find the target of the hook
							hooks.append(HookData(hooked_module, export_name, [CallsiteData(module.get_filename().split("\\")[-1], func_addr, None, (mbi.Protect & win32.PAGE_EXECUTE_READWRITE) != 0, module.signed)]))
				else:
					mbi = process.mquery(func_addr)				
					hooked_module = module.filename
					if (mbi.Protect & win32.PAGE_EXECUTE_READWRITE):
						hooks.append(HookData(hooked_module, export_name, [CallsiteData(hooked_module, func_addr, None, True, module.signed)]))
			except KeyboardInterrupt as ex:
				break
			except:
				pass

							

# Now we can enumerate the running processes.
if __name__ == "__main__":
	System.request_debug_privileges()
	proc_to_scan = None
	scan_by_pid = False
	if len(sys.argv) > 1:
		try:
			proc_to_scan = int(sys.argv[1])
			scan_by_pid = True
		except:
			proc_to_scan = sys.argv[1].lower()
	for process in system:
		if process.get_filename():
			if proc_to_scan is None or (scan_by_pid and process.get_pid() == proc_to_scan) or (not scan_by_pid and proc_to_scan in process.get_filename().lower()):
				print "Scanning %d:\t%s" % ( process.get_pid(), process.get_filename() )        
				try:
					hooks = []
					scan_for_bad_hooks(process, hooks)
					if hooks:
						headers =  ["Export", "Module", "Source", "Target", "RWX", "Signed", "Unsafe"]
						table = []
						for hook in hooks:
							for row in hook.to_rows():
								table.append(row)
						print
						print tabulate.tabulate(table, headers, tablefmt="grid")
				except:
					print
					print "Can't Scan %s" % (process.get_filename())



